<?php
include '../db/db_conn.php';
include '../db/config.php';

// 프로그램은 위에서 아래 (순서 햇갈리지 마세요.)
// 1. 이 유저가 마스터인지 아닌지 (user_type 컬럼에서 3이면 접속)
// 2. DB연동을 해야한다.
// 3. 잘못된 값이 있는지 확인한다.
// 4. 수정버튼 (modify를 get방식으로 불러올때 수정인지 아닌지)


// 1. 파일업로드 부터 확인한다.
if(isset($_FILES['notice_file'])) {
  $file_name = $_FILES['notice_file']['name']; //파일명
  $file_size = $_FILES['notice_file']['size']; //파일크기
  $file_tmp = $_FILES['notice_file']['tmp_name']; //파일명
  $file_type = $_FILES['notice_file']['type']; //파일유형

  $ext = explode('.',$file_name); 
  $ext = strtolower(array_pop($ext));
  //file.hwp -> [file] [hwp]

  $expensions = array("jpeg", "jpg", "png", "pdf", "hwp", "docx", "pptx", "ppt", "txt", null); //올라갈 파일 지정
  //SWF나 EXE같은 악성코드 배포방지
  
  if(in_array($ext, $expensions) === false){ //해당 확장자가 아니라면
    $errors[] = "올바른 확장자가 아닙니다.";
  } //경고

  if($file_size > 2097152) { //2MB이상 올라가면
    $errors[] = '파일 사이즈는 2MB 이상 초과할 수 없습니다.';
  } //경고

  if(empty($errors) == true) { //에러가 없다면
    move_uploaded_file($file_tmp, "./files/".$file_name); //경로에 저장
    $files = $file_name; // 변수에 파일명을 담는다
  } else { //경고가 있다면
    print_r($errors); //경고출력
  }
} else { // 만약 이미지 업로드가 아니라면
  $files = null; //null로 반환한다.
}

// 2. 다음은 글 내용을 받아온다.
$id = $_SESSION['lms_logon'] ?? '';
$idsql = "select user_type from user_table where user_id = '$id'";
$res = mysqli_query($conn, $idsql);
$row = mysqli_fetch_assoc($res); // 배열로 값을 가져온다.
$user_type = $row['user_type'] ?? 0; //관리자 권한

$notice_title=$_POST['notice_title'];
$notice_text=$_POST['notice_text'];
$notice_date = date('Y-m-d (h:i:s)');

// 3. 받아온 값들을 DB에 담는다. 


if($id){//사용자가 수정한 아이디값이 같은 경우 (수정일 경우)

    $query = "update notice set
    notice_title='$notice_title',
    notice_text='$notice_text',
    notice_file='$notice_file'
    where num='$id'";

    mysqli_query($conn, $query);
    

}else{//새 글일 경우 insert구문 작성한다
$sql = "insert notice_list set notice_title='$notice_title', notice_text='$notice_text', notice_file='$files', notice_date='$notice_date'";
}

mysqli_query($conn, $sql); // sql에 저장된 명령 실행
mysqli_close($conn); //종료


?>

<script>
  location.href="notice_list.php";
  // location.replace
</script>