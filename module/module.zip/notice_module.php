<?php

$data = [
  'notice_title' => '',
  'notice_text' => '',
  'notice_file' => ''
];
//http://localhost/myongji/module/notice.php?id=1

$id = $_GET['id']; // 주소창에서 받아오는 값
$id = (int)$id;
$id = mysqli_real_escape_string($conn, $id); // SQL 인젝션 방지용
$query = "select * from notice_list where num= $id "; // 쿼리문
$result = mysqli_query($conn, $query); // DB에 쿼리문을 실행하게 한다
$data = mysqli_fetch_array($result); // 결과값을 불러온다

$view_sql = "UPDATE notice_list set notice_views = notice_views + 1 where num = {$id}";
mysqli_query ($conn, $view_sql);
?>

<main>
<form name='write' method="post" action="writePost.php" enctype="multipart/form-data">
  <input type="hidden" name="id" value="<?=$id?>">
  <article>
  <table>
    <colgroup>
      <col width="100">
      <col width="700">
    </colgroup>
    <caption>게시글</caption>
    <tr>
      <th>제목</th>
      <td><?=$data['notice_title']?></td>
    </tr>
    <tr>
      <th>내용</th>
      <td><?=nl2br($data['notice_text'])?></td>
    </tr>
    <tr>
      <th>첨부파일</th>
      <td>
      <?php
        if($data['notice_file'] > 0){
          echo '<a href="./files/'. $data['notice_file'] .'">';
          echo $data['notice_file'];
          echo '</a>';
        } else {
          echo '-';
        }
      ?>
      </td>
    </tr>
    <tr>
      <td colspan="2">
        <?php
        if($userType == 1){?>
        <a href="confirmDel.php?id=<?=$id?>">삭제</a>
        <?php } else {
        } ?><a href="confirmDel.php?id=<?=$id?>">삭제</a>
        <a href="notice_write.php?id=<?=$id?>&modify=1">수정</a>
      </td>
    </tr>
  </table>
  <p><a href="notice_list.php" title="글목록보기">글목록보기</a></p>
  </article>
</form>
</main>