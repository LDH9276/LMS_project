<?php

$num = $_GET['id'] ?? '0';
$id = $_GET['modify']?? '0'; //php 7.4 이상 반드시 넣어야한다.
$notice_title = $_GET['notice_title'] ?? '';
$notice_text = $_POST['notice_text'] ?? '';
$notice_file = $_POST['notice_file'] ?? '';


if(!$id == '1'){
  $data['notice_title'] = null;
  $data['notice_text'] = null;
  $data['notice_file'] = null;
} else {
  $query = "select * from notice_list where num='$num'";
  $result = mysqli_query($conn, $query);
  $data = mysqli_fetch_array($result);
}
?>


    <main>
      <div class="right">

      </div>
      <form name='write' method="post" action="writePost.php" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?=$id?>">
      <article>
        <table>
          <colgroup>
            <col width="100">
            <col width="700">
          </colgroup>
          <caption>글 입력화면</caption>
          <tr>
            <th>제목</th>
            <td><input type="text" name="notice_title" value="<?=$data['notice_title']?>" id="notice_title"></td>
          </tr>

          <tr>
            <th>내용</th>
            <td>
              <textarea name="notice_text" id="notice_text"><?=$data['notice_text']?></textarea>
          </td>
          </tr>
          <tr>
            <th>첨부파일</th>
            <td><input type="file" name="notice_file" id="notice_file"><?=$data['notice_file']?></td>
          </tr>

          <tr>
            <th colspan="2">
              <p><input type="submit" value="등록"></p>
              <p><button type="button" id="n_btn" onclick="document.location.href='notice_list.php'">목록</button></p>
            </th>
          </tr>
        </table>
      </article>
      </form>
    </main>

  </body>
</html>