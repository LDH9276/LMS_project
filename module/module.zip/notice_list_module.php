
    <main>
      <div class="right">

      </div>
      <section>
        <h2>공지사항</h2>
        <div class="nl_pg">
          <a href="../index.php" title="메인으로 바로가기"><i class="fa-solid fa-house"></i></a>
          <p>&gt;</p>
          <a href="notice_list.php" title="공지사항 리스트">공지사항</a>
        </div>
        <hr>
        <table class="n_list">

        <colgroup>
          <col width="100">
          <col width="350">
          <col width="200">
          <col width="150">
        </colgroup>
          <tr>
            <th>번호</th>
            <th>제목</th>
            <th>첨부</th>
            <th>등록일</th>
            <th>조회수</th>
          </tr>
          
          <tr>
            <?php
              $query = 'select * from notice_list order by num desc limit 0,10'; //가장 최신글을 위로 올라오게 조회하여 변수에 저장

              $result = mysqli_query($conn, $query);
              while($data = mysqli_fetch_array($result)){
            ?>
          </tr>
          <tr>
            <td><?=$data['num']?></td>
            <td><a href="notice.php?id=<?=$data['num']?>"><?=$data['notice_title']?></a></td>
            <td>
              <?php
                if($data['notice_file'] > 0){
                  echo '<a href="./files/'. $data['notice_file'] .'"><i class="fa-solid fa-download"></i></a>';
                } else {
                  echo '-';
                }
              ?>
            </td>
            <td><?=substr($data['notice_date'],0,10)?></td>
            <td><?=$data['notice_views']?></td>
          </tr>
          <?php } ?>


        </table>
        <p>
          <input type="search" placeholder="검색어를 입력해주세요">
          <a href="notice_write.php" title="글 입력을 위한 페이지로이동하기">글쓰기</a>
        </p>
      </section>
    </main>

  </body>
</html>